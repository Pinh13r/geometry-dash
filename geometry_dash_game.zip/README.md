# Geometry Dash Web Game

This is a full-featured Geometry Dash-style game made in HTML5 and JavaScript.

## How to Use

1. Upload `index.html` and your `music.mp3` to a GitHub repository.
2. Go to Repository Settings → Pages
3. Set the source to `main` branch, root folder.
4. GitHub will give you a live game link like:
   `https://yourusername.github.io/geometry-dash/`

Enjoy!
